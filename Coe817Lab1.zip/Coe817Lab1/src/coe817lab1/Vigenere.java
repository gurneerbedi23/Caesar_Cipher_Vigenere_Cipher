package coe817lab1;
import java.util.Scanner;

public class Vigenere {
    //method to encypt the message, takes arguments text and userkey and returns
    //the encrypted message. 
    public static String encrypt (String text, String userkey){
     String ciphertext = "";
     text = text.toUpperCase(); //convert plaintext to upper case characters because algorithm uses ASCII
     /*Each character corresponds to a specific integer according to the ASCII table. The letter 'A' is 65 
     therefore we need to compensate by using an offset of 65 in the cipher character's calculation. %26 because there are a total of 26 characters.
     For loop runs through each character of the plaintext and the key and adds them up one by one to the ciphertext
     */ 
     for(int count = 0, count2 = 0; count < text.length(); count++){
         char c = text.charAt(count);
         ciphertext += (char)(((c - 65)+(userkey.charAt(count2)-65)) % 26 + 65);
         count2 = ++count2 % userkey.length();
          //userkey also needs to wrap around the plaintext if the plaintext is longer than the key
     }
     return ciphertext;
     //System.out.println("Ciphertext: " + ciphertext);
    }

   
 public static String decrypt (String text, String userkey) {
         String plaintext = "";
         text = text.toUpperCase();
         for (int count3 = 0, count4 = 0; count3 < text.length(); count3++){
            char c = text.charAt(count3);
            //similar to the encrypt method but plaintext is calculated by subtracting the key's value 
            plaintext += (char)((c - userkey.charAt(count4)+26) % 26 + 65);
            count4 = ++count4 % userkey.length();
}
         return plaintext;
         //System.out.println("Decrypted Text: " + plaintext);
 }
    public static void main (String [] args ){
        Scanner in = new Scanner (System.in);
   
    //Part B: ask user to enter message: "TO BE OR NOT TO BE THAT IS THE QUESTION"
    System.out.print("Enter the message to be encrypted: ");
    String plaintext = in.nextLine();
    //Ask the user for the Vigenere key "RELATIONS"
    System.out.print("Enter the Vigenere key: ");
    String userkey = in.nextLine();
    //Encode the message using the Vigenere cipher 
    String encryptedtext = encrypt(plaintext,userkey);
    //Print the encrypted text 
    System.out.println("The encrypted text is: " + encryptedtext);
    
     System.out.print("Enter the message to be decrypted: ");
    String ciphertext = in.nextLine();
    //Ask the user for the Vigenere key "RELATIONS"
    System.out.print("Enter the Vigenere key: ");
    String userkey2 = in.nextLine();
    //Decode the message using the Vigenere cipher
    String decrypted = decrypt(ciphertext,userkey2);
     //Print the reuslt of decrypting the encrypted text (original text) 
    System.out.println("the decrypted text is: " + decrypted); 
    }
}

